import './Adminlogin.css'
import React from 'react'
import { useState, } from 'react';
import { useHistory } from 'react-router-dom';
import Navbar from './Navbar';
import axios from 'axios'


const Adminlogin = ()=>
{
    const [username,setUsername] = useState(''); 
    const [password,setPassword] = useState('');
    const history = useHistory();

    const goInsideLogin = ()=>
    {
      if (username.length === 0) {
        alert('Please Enter Username')
      } 
      else if (password.length === 0) {
        alert('Please Enter Password')
      }
      else{
       
        
        // const data = new FormData()
        // data.append('userName',username)
        // data.append('password',password)
        // This is feasible to be used while connecting the spring boot backend 

        const data = {
          userName :  username,
          password :  password
        }

      
        
        axios.post('http://localhost:4000' + '/userRoute/adminlogin',data).then((response)=>
        {
          const result = response.data
          console.log(response.data)
          if(result.status === 'success')
            { 
              history.push('/home');
            }
          else if(result.status==='')
          {
            
            alert("Wrong Login Credentials Try Again !!!!")
          
          }
        
        })  
       
        }
      }
    return<>
    <Navbar />
     
    <header id="home-section">
      <div className="dark-overlay">
        <div className="home-inner container">
          <div className="row">
            <div className="col-lg-8 d-none d-lg-block">
              <h1 className="display-3 texts">
                <strong>Fresh Eggs</strong><br />
                &ensp;To Be Served
              </h1>
              
  
              <div className="d-flex">
                <div className="p-4 align-self-start">
                  
                </div>
                <div className="p-4 align-self-end">
                
                </div>
              </div>
            </div>
            <div className="form-box">
              <div className="header-text">
                Login Form
              </div>
              <input 
              onChange={(e) => {
                setUsername(e.target.value)
              }} 
              
              placeholder="Username" type="text" /> 
              <input 
              onChange={(e) => {
            setPassword(e.target.value)
              }}
              placeholder="Password" type="password" /> 
              
              <input style={{textAlign:"center",background:"blue",color:"black"}} onClick={goInsideLogin} type="submit" value= "Admin-login" /> 
            </div>
          </div>
        </div>
      </div>
    </header>
    
    </>
}

export default Adminlogin