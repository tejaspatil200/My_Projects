import React from 'react';
import { Link } from 'react-router-dom';
import Navbar from './Navbar';


function Admindashboard() {
  return <div>
    
       <nav class="navbar navbar-expand-sm navbar-dark bg-dark fixed-top">
      <div class="container">
        <a href="" style={{marginLeft:"10px"}} class="navbar-brand">POULTRY FARMING - ADMIN</a>
        <button
          class="navbar-toggler"
          data-toggle="collapse"
          data-target="#navbarCollapse"
        ></button>
        <div className='navbar-nav'>
        <Link className="nav-link  ms-auto  as" to ="/home">Home</Link>
        <Link className="nav-link  as" to ="/feedr">Feed-Record</Link>
        <Link className="nav-link  as" to ="/birdr">Bird-Record</Link>
        <Link className="nav-link  as" to ="/eggr">Egg-Record</Link>
        <Link className="nav-link  as" to ="/orders">Orders</Link>
        </div>
        </div>
    </nav>

  
  </div>;
}

export default Admindashboard;
