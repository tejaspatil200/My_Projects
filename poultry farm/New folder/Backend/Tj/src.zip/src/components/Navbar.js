import React from 'react'


const Navbar =()=>
{
    return<>
    <nav class="navbar navbar-expand-sm navbar-dark bg-dark fixed-top">
      <div class="container">
        <a href="" class="navbar-brand">POULTRY FARMING - ADMIN</a>
        <button
          class="navbar-toggler"
          data-toggle="collapse"
          data-target="#navbarCollapse"
        ></button>
        </div>
    </nav>
    </>
}

export default Navbar