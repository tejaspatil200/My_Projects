import React from 'react';
import Admindashboard from '../Admindashboard';
import './Eggrecord.css'
import axios from 'axios';
import { useState,useEffect } from 'react';

// axios liberary
function Eggrecord() {
  const [egg,setEgg] = useState([])
  const [adegg,setAdegg] = useState([])
  const [edegg,setEditegg] = useState([])

  useEffect(()=>
  {
    console.log("Bird is Loaded");
    getEgg()

  },[])

  const getEgg=()=>
  {
    axios.get('http://localhost:4000' + '/records/geteggs').then((response) => {
      const result = response.data
      if (result.status === 'success') {
        setEgg(result.data)
         console.log(result.data)
      } else {
        alert('error')
      }
    })
  }

  const addEgg=()=>
  {
    var data ={
      eggs_qty : adegg
    }
    console.log(data)

    axios.post('http://localhost:4000' + '/records/inserteggs',data).then((response)=>
    {
      console.log(response)
      const result = response.data
      
          alert("Eggs Added Successfully")
          window.location.href="/eggr"
          // setAddbirds(result.data)
    
    })

  }



  const editegg=()=>
  {

    var data ={
      eggs_qty : edegg
    }
  
    axios.post('http://localhost:4000' + '/records/editeggs',data).then((response)=>
    {
     
      alert("eggs Edited successfully")
      window.location.href="/eggr"
    })

  }


  return <div>
    <Admindashboard />
    <div className='outimg'>
    <div style={{backgroundColor:'#FAF3F3'}}><h2 style={{marginTop:"60px",color:'black'}}><b>Egg-Record</b></h2></div>
    
    <div className="eggfeedbox mt-4" style={{color:"black"}}>
      <h5 className="mt-5">Add Eggs:</h5>
      <input 
      style={{textAlign:"center"}}
      onChange={(e) => {
        setAdegg(e.target.value)
      }}
      type="number"></input><br />


      {/* <button type="button" class="btn btn-primary mt-3">Edit-Eggs</button> */}
       <button onClick={addEgg} type="button" class="btn btn-primary mt-3 mx-3">Save-Eggs</button><br /><br />
      <h5>Eggs Available:</h5>
      <input style={{textAlign:'center'}} type="number" value={egg.eggs_quantity}></input>
      <h5 className="mt-3">Edit Egg Entry:</h5>
      <input 
      style={{textAlign:"center"}}
      onChange={(e) => {
        setEditegg(e.target.value)
      }} 
      type="number"></input><br />
      <button type="button" onClick={editegg} class="btn btn-primary mt-3">Edit-Entry</button>
       {/* <button type="button" onClick={addEgg} class="btn btn-primary mt-3 mx-3">Add-Entry</button><br /><br /> */}
      
      </div>
    
 
    
    </div>
   
  </div>;
}

export default Eggrecord;
