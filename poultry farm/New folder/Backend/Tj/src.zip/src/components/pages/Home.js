import React, { useEffect,useState } from 'react';
import Admindashboard from '../Admindashboard';
import './Home.css'
import axios from 'axios';


function Home() {

  const [dataa, setDataa] = useState([])

  useEffect(() => {
    console.log(`Statistics got loaded`)
    getData()
  }, [])

  const getData = () => {
    axios.get('http://localhost:4000' + '/dashboard/getrecord').then((response) => {
      const result = response.data
      
      if (result.status === 'success' ) {
         setDataa(result.data)
        
      } else {
        
      }
    })
  }

  return <div>
    <Admindashboard />
    <div className='ouimage'>
    <div style={{marginTop:'60px'}}>
    <div style={{backgroundColor:'#FAF3F3'}}><h2 style={{marginTop:"60px",color:'black'}}><b>Statistics</b></h2></div>
    <div className='tableouter'>
    <table class="table table-striped table-dark" style={{margin:"0px"}}>
  
  <tbody>
    
    <tr>
      
      <td><h5 className='display-' style={{color:"white",paddingTop:"60px"}}> Available Birds:</h5></td>
      <td style={{color:"white",paddingTop:"60px"}}><h5 className='display-6'>{dataa.available_birds}&ensp;Pcs</h5></td>
      
    </tr>
    <tr>
      
      
     <td> <h5 className='display-6' style={{color:"white",paddingTop:"60px"}}> Available Feed:</h5></td>
     <td style={{color:"white",paddingTop:"60px"}}><h5 className='display-6'> {dataa.available_feeds}
     &ensp; Kg</h5></td>
    </tr>
    <tr>
      
      <td> <h5 className='display-6' style={{color:"white",paddingTop:"60px"}}> Available Eggs:</h5></td>
      <td style={{color:"white",paddingTop:"60px"}}><h5 className='display-6'> 
      {dataa.available_eggs}&ensp; Pcs</h5></td>
     
    </tr>
    
    <tr>
   
      <td> <h5 className='display-6' style={{color:"white",paddingTop:"60px"}}> Available Birds For Sale:</h5></td>
      <td style={{color:"white",paddingTop:"60px"}}><h5 className='display-6'>{dataa.birds_sale} &ensp; Pcs</h5></td>
     
    </tr>
  </tbody>
</table>
</div>
</div>
    
</div>
  </div>;
}

export default Home;
