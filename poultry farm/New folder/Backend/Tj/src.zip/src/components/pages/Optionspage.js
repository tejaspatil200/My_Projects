
import React from 'react';
import Navbar from '../Navbar';
import './Optionspage.css'
import { useHistory } from 'react-router-dom';


function Optionspage() {
    const history = useHistory();

    const adminpage =()=>
    {
        history.push('/adlog');
    }

    const custpage =()=>
    {
        history.push('/cslog');
    }

    return(
        <div className='outimg'>
              <nav class="navbar navbar-expand-sm navbar-dark bg-dark fixed-top">
      <div class="container">
        <a href="" class="navbar-brand">WELCOME TO POULTRY FARMING</a>
        <button
          class="navbar-toggler"
          data-toggle="collapse"
          data-target="#navbarCollapse"
        ></button>
        </div>
         </nav>
        <div style={{color:"black"}}>
           <button  onClick={custpage} type="button" class="btn btn-success btn-lg mx-5 buton">Customer-Order</button>
           <button  onClick={adminpage} type="button" class="btn btn-primary btn-lg mx-5 buton">Admin-Login</button>
        </div>
        </div>
    )

  
    
  
}

export default Optionspage;
