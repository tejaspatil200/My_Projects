import React from "react";
import './CustomerOrder.css'
import { useState, } from 'react';
import { useHistory } from 'react-router-dom';
import axios from 'axios'

const CustomerOrder = () => {
  const [name, setName] = useState('');
  const [address, setAddress] = useState('');
  const [phone, setPhone] = useState('');
  const [type, setType] = useState('');
  const [qty, setqty] = useState();
  const history = useHistory();

  const submits = () => {

    const data = {
      Name: name,
      Address: address,
      Phone: phone,
      Type: type,
      Quantity: qty
    }
    console.log(data)



    axios.post('http://localhost:4000/custOrder/orders', data).then((response) => {
      const result = response.data
      console.log(response.data)
      if (result.status === 'success') {
        alert("Order succesfully placed")

        window.location.href='/';
      }
      else if (result.status === '') {

        alert(" Try Again !!!!")

      }

    })

  }


  return <div>
    <h1>
      <nav class="navbar navbar-expand-sm navbar-dark bg-dark fixed-top">
        <div class="container">
          <a href="" class="navbar-brand"><h1>WE HAVE GOT EGGS AND CHICKEN AT YOUR DOORSTEPS </h1><br></br>-fill the form below &nbsp;&nbsp;&nbsp;[Egg- 5&#x20B9;/pc &nbsp;&nbsp;&nbsp; Chicken- 100&#x20B9;/pc &nbsp;&nbsp;&nbsp; Cash on delivery only/-]</a>

          <button
            class="navbar-toggler"
            data-toggle="collapse"
            data-target="#navbarCollapse"
          ></button>
        </div>
      </nav>
    </h1>

    <form>
      <div class="form-group forms">
        <label>Enter Name</label>
        <input
          onChange={(e) => {
            setName(e.target.value)
          }}

          type="text" class="form-control" placeholder="Enter Name" required />
      </div>


      <div class="form-group">
        <label >Enter Address</label>
        <textarea

          onChange={(e) => {
            setAddress(e.target.value)
          }}

          class="form-control" placeholder="Enter Address" required></textarea>
      </div>


      <div class="form-group ">
        <label>Enter Phone-number</label>
        <input
          onChange={(e) => {
            setPhone(e.target.value)
          }}
          type="text" class="form-control" placeholder="Enter Phone-number" required />
      </div>


      {/* <div class="form-group ">
                <label>What do you want</label>
                <input 
                onChange={(e) => {
                    setType(e.target.value)
                      }} 
                      type="text" class="form-control"   placeholder="What do you want - Egg or Chicken" required/>
                </div> */}
      <div style={{ margin: "auto" }} class="form-group col-md-4">
        <label for="inputState">State</label>
        <select id="inputState" class="form-control" onChange={(e) => {
          setType(e.target.value)
        }} >
          <option selected>What Do You Want</option>
          <option>Egg</option>
          <option>Chicken</option>
        </select>
      </div>


      <div class="form-group ">
        <label>Quantity</label>
        <input
          onChange={(e) => {
            setqty(e.target.value)
          }}
          type="number" class="form-control" placeholder="Quantity" required />
      </div>


      <button onClick={submits} type="submit" class="btn btn-primary">Submit</button>
    </form>

  </div>
}

export default CustomerOrder