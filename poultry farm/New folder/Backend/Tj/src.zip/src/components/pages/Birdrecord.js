import React from 'react';
import Admindashboard from '../Admindashboard';
import './Birdrecord.css'
import axios from 'axios';
import { useState,useEffect } from 'react';



function Birdrecord() {
  const [bird,setBird] = useState([])
  const [addbirds,setAddbirds] = useState(0)
  // const [editbirds,seteditbirds] = useState([])
  const [addsalebird,setAddsalebird] = useState([])

  useEffect(()=>
  {
    console.log("Bird is Loaded");
    getBird()

  },[])

  const getBird=()=>
  {
    axios.get('http://localhost:4000' + '/records/getbirds').then((response) => {
      const result = response.data
      if (result.status === 'success') {
        setBird(result.data)
         console.log(result.data)
      } else {
        alert('error')
      }
    })
  }


  const addBird=()=>
  {
    var data ={
      bird_qty : addbirds
    }
    console.log(data)

    axios.post('http://localhost:4000' + '/records/insertbirds',data).then((response)=>
    {
      console.log(response)
      const result = response.data
      
          alert("new birds added")
          window.location.href="/birdr"
          // setAddbirds(result.data)
    
    })

  }
  const addSbird=()=>
  {

    var data ={
      bsale_qty : addsalebird
    }
  
    axios.post('http://localhost:4000' + '/records/insertsalebirds',data).then((response)=>
    {
    
     
      alert("Sale birds are Updated")
      window.location.href="/birdr"
    })

  }


  const editSbird=()=>
  {

    var data ={
      bsale_qty : addsalebird
    }
  
    axios.post('http://localhost:4000' + '/records/editsalebirds',data).then((response)=>
    {
     
      alert("Sale birds are Edited")
      window.location.href="/birdr"
    })

  }
 const editBird=()=>
  {
    var data ={
      bird_qty : addbirds
    }
    console.log(data)

    axios.post('http://localhost:4000' + '/records/editbirds',data).then((response)=>
    {
      console.log(response)
      const result = response.data
      
          alert("All birds are edited")
          window.location.href="/birdr"
          
    
    })

  }
  return <div>

    
    <Admindashboard />
    <div className='outerimage'>
    <div style={{backgroundColor:'#FAF3F3'}}><h2 style={{marginTop:"60px",color:'black'}}><b>Bird-Record</b></h2></div>


    <div className='birdr' style={{color:"black",margin:"auto"}}>
        <div className="birdfeedbox mt-4" style={{color:"black"}}>

          <h5 className="mt-5"><b>Add New Bird:</b></h5>
          <input   style={{textAlign:"center"}}onChange={(e) => {
                setAddbirds(e.target.value)
              }
          }className='inputt' type="number"></input><br />
          <button onClick={addBird} type="button" class="btn btn-primary mt-3 mx-3">Add-Bird</button>
          <button onClick={editBird} type="button" class="btn btn-primary mt-3 mx-3">Edit-Bird</button><br />

          <h5 className="mt-3"><  b>Add Birds For Sale:</b></h5>
          <input style={{textAlign:'center'}} onChange={(e) => {
                setAddsalebird(e.target.value)
              }
          }className='inputt' type="number"></input><br />
          <button onClick={addSbird}type="button" class="btn btn-primary mt-3 mx-3">Add-Bird</button>
          <button onClick={editSbird}type="button" class="btn btn-primary mt-3 mx-3">Edit-Bird</button><br /><br />

          <h5><b>Available Record:</b></h5>
            <input style={{textAlign:'center'}}className='inputt' type="number" value={bird.bird_quantity}></input>

          <h5 className="mt-3"><  b>Available Birds For Sale:</b></h5>
            <input style={{textAlign:'center'}} className='inputt' type="number" value={bird.bsale_quantity}></input><br />
      
      
       
      
    </div>
    </div>
    </div>
  </div>;
}

export default Birdrecord;
