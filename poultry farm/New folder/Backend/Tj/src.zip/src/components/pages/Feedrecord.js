import React from 'react';
import Admindashboard from '../Admindashboard';
import './Feedrecord.css'
import axios from 'axios';
import { useEffect,useState} from 'react';


function Feedrecord() {

  const [feeds, setFeed] = useState([])
  const [adfeeds, setAdfeeds] = useState(0)
  const [dlfeeds, setDlfeeds] = useState(0)

  useEffect(() => {
    console.log(`Feed got loaded`)
    getFeed()
  },[])

  const getFeed = () => {
    axios.get('http://localhost:4000' + '/records/getfeeds').then((response) => {
      const result = response.data
      if (result.status === 'success') {
         setFeed(result.data)
         console.log(result.data)
      } else {
        alert('error while loading list of feed')
      }
    })
  }

  const addFeed = () => {
    const data = {
      feed_qty :  adfeeds
      
    }

    axios.post('http://localhost:4000' + '/records/insertfeeds',data).then((response) => {
      const result = response.data
      if (result.status === 'success') {
         alert('Feed Added Sucessfully')
         window.location.href="/feedr"
        //  getFeed()
      } else {
        alert('error while loading list of feed')
      }
    })
  }

  const delFeed = () => {
    const data = {
      feed_qty :  dlfeeds
      
    }

    axios.post('http://localhost:4000' + '/records/insertdailyfeeds',data).then((response) => {
      const result = response.data
      if (result.status === 'success') {
         alert('Feed Removed Sucessfully')
         window.location.href="/feedr"
        //  getFeed()
      } else {
        alert('error while loading list of feed')
      }
    })
  }
  return <div>
    <Admindashboard />
    <div className='outerimg'>
    <div style={{backgroundColor:'#FAF3F3'}}><h2 style={{marginTop:"60px",color:'black'}}><b>Feed-Record</b></h2></div>
    
 
    <div className="feedfeedbox mt-4" style={{color:"black"}}>
      <h5 className="mt-5"><b>New Feed Entry:</b></h5>
      <input style={{textAlign:"center"}}
      onChange={(e) => {
        setAdfeeds(e.target.value)
      }} 
      type="number"></input><br />
       <button   onClick={addFeed} type="button" class="btn btn-primary mt-3 mx-3">Save-Feed</button><br /><br /> 


      <h5><b>Feed Available:</b></h5>
      <input style={{textAlign:'center'}}type="number" value={feeds.quantity}></input>



      <h5 className="mt-3"><b>Daily Feed Consumption:</b></h5>
      <input style={{textAlign:'center'}} 
       onChange={(e) => {
        setDlfeeds(e.target.value)
      }}
      type="number"></input><br />
      <button  onClick={delFeed} type="button" class="btn btn-primary mt-3">Feed-Consumed</button>
       {/* <button type="button" class="btn btn-primary mt-3 mx-3">Edit</button><br /><br /> */}
      
    
       </div>
    </div>
  </div>;
}

export default Feedrecord;
