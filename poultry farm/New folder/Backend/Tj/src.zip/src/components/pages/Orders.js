import React from 'react';
import Admindashboard from '../Admindashboard';
import  { useState } from 'react';
import Navbar from './../Navbar';
import './Orders.css'
import axios from 'axios';
import { useEffect } from 'react';

function Orders() {
  const [order, setOrder] = useState([])

  useEffect(() => {
    console.log(`Order component got loaded`)
    getOrders()
  }, [])

  const getOrders = () => {
     axios.get('http://localhost:4000' + '/custOrder/getorders').then((response)  => {
      const result = response.data
      if (result.status === 'success') {
        setOrder(result.data)
      } else {
        alert('error while loading list of Orders')
      }
    })
  }

  return <div style={{color:"black"}}> 
    <Admindashboard />
    <div className='tableoute my-5'>
    <table class="table table-striped  asd" >
    <thead>
    <tr>
      <th>Name of customer</th>
      <th>Order-ID</th>
      <th>Order Date</th>
      <th>Order Type</th>
      <th>Customer Address</th>
      <th>Contact Number</th>
    </tr>
    </thead>
    <tbody>
    {order.map(x=>(
                    <tr>
                      <td>{x.customerName}</td> 
                        <td>{x.order_Id}</td>
                        <td>{x.order_date.substring(0,10)}</td>
                        <td>{x.type}</td>
                        <td>{x.address}</td>
                        <td>{x.phone}</td>
                       
                    </tr>
                ))}
    </tbody>
    
    
  
</table>
</div>
    
   
   
    
  </div>;
}

export default Orders;
