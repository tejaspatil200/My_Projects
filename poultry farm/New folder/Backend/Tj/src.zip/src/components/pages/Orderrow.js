import React from 'react';

const Orderrow = ({ odr }) => {

    // const audio = new Audio( 'http://localhost:4000' + '/records/getorders')

    return(
        <tr>
            <td>{odr.name}</td>
            <td>{odr.order_id}</td>
            <td>{odr.order_date}</td>
            <td>{odr.order_type}</td>
        </tr>
    )
    
}
export default Orderrow

{/* <tr>
<td>{orders.name}</td>
<td>{orders.order_id}</td>
<td>{orders.order_date}</td>
<td>{orders.order_type}</td> 
</tr> */}