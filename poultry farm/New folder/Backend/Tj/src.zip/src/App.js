
import './App.css';
import Adminlogin from './components/Adminlogin';
import { BrowserRouter,Route,Switch } from 'react-router-dom';
import Admindashboard from './components/Admindashboard';
import Orders from './components/pages/Orders';
import Feedrecord from './components/pages/Feedrecord';
import Home from './components/pages/Home';
import Eggrecord from './components/pages/Eggrecord';
import Birdrecord from './components/pages/Birdrecord';
import Optionspage from './components/pages/Optionspage';
import CustomerOrder from './components/pages/CustomerOrder';

function App() {
  return (
    <div className="App">
    

     <BrowserRouter>
     
     {/* <Adminlogin />
     <Admindashboard /> */}

     <Switch>
    <Route exact path="/"  component={Optionspage} /> 
    <Route exact path="/adlog" component={Adminlogin} /> 
    <Route exact path="/cslog" component={CustomerOrder} /> 
    <Route exact path="/dashboard" component={Admindashboard} />
    <Route exact path="/feedr" component={Feedrecord} />
    <Route exact path="/birdr" component={Birdrecord} />
    <Route exact path="/eggr" component={Eggrecord} />
    <Route exact path="/orders"  component={Orders} />
    <Route exact path="/home" component={Home} />
  

</Switch>
     </BrowserRouter>
    </div>
  );
}

export default App;
